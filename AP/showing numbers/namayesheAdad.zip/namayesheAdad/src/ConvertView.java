import java.util.Scanner;

public class ConvertView {

	public static long TabdilBeAdad(String harf) {
		// daryaft harfe joda shode va tabdile an be adad az tarigh i moshabehe
		// arrayeha
		long a[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
				17, 18, 19, 20, 30, 40, 50, 60, 70, 80, 90, 100, 200, 300, 400,
				500, 600, 700, 800, 900, 1000, 1000000, 1000000000 };
		String b[] = { "Sefr", "Yek", "Do", "Seh", "Chahar", "Panj", "Shesh",
				"Haft", "Hasht", "Noh", "Dah", "Yazdah", "Davazdah", "Sizdah",
				"Chahardah", "Panzdah", "Shanzdah", "Hefdah", "Hejdah",
				"Noozdah", "Bist", "Si", "Chehel", "Panjah", "Shast", "Haftad",
				"Hashtad", "Navad", "Sad", "Divist", "Sisad", "Chaharsad",
				"Pansad", "Sheshsad", "Haftsad", "Hashtsad", "Nohsad", "Hezar",
				"Million", "Milliard" };
		String[] j;
		int i;
		long arr[] = { 0, 1 };
		int x = harf.indexOf(' ');// donbale fasele migrde
		if (x != -1) {// age fasele dasht joda mikone
			j = harf.split(" ");

			for (i = 0; i <= 39; i++) {// tabdil adad
				boolean dorosti = b[i].equals(j[0]);
				if (dorosti == true) {
					arr[0] = a[i];// adad
					break;
				}
			}

			for (i = 0; i <= 39; i++) {
				boolean dorosti = b[i].equals(j[1]);
				if (dorosti == true) {
					arr[1] = a[i];// hezar million milliard
					break;
				}
			}
			long u = arr[1] * arr[0];// jodai ha zarb mishavand

			return u;
		}

		else {
			for (i = 0; i <= 39; i++) {
				boolean dorosti = b[i].equals(harf);
				if (dorosti == true)
					break;
			}
			return a[i];
		}

	}

	public static String BeAdad(String lett) {

		long argham[], h = 0;
		argham = new long[12];

		int u;
		u = lett.indexOf("Tilliard");// ghesmate error
		if (u != -1)
			return "khata\n adad toolani tar az hade momken ast";

		u = lett.indexOf("Hezar Milliard");// ghesmate error
		if (u != -1)
			return "khata\n adad toolani tar az hade momken ast";

		else {

			String[] letts = lett.split(" o ");

			for (int j = 0; j < letts.length; j++) {

				argham[j] = TabdilBeAdad(letts[j]); // Tabdil

			}
			long p;
			for (int j = 0; j < argham.length; j++) {// jame tabdiliha
				p = 0;
				if (argham[j] % 1000 == 0 && argham[j] % 1000000 != 0
						&& argham[j] % 1000000000 != 0 && argham[j] != 1
						&& argham[j] != 0) {
					p = argham[j] / 1000;
					h = p + h;
					h = h * 1000;
				} else if (argham[j] % 1000000 == 0
						&& argham[j] % 1000000000 != 0 && argham[j] != 1
						&& argham[j] != 0) {
					p = argham[j] / 1000000;
					h = p + h;
					h = h * 1000000;
				} else if (argham[j] % 1000000000 == 0 && argham[j] != 1
						&& argham[j] != 0) {
					p = argham[j] / 1000000000;
					h = p + h;
					h = h * 1000000000;

				} else if (argham[j] == 0)
					{h = argham[j] + h;
					break;}
				else {
					h = argham[j] + h;// jam krdn adad
				}

			}
			String num = String.valueOf(h);// tabdil int b string

			return num;
		}

	}

	// ***************************ok
	public static String TabdilBeHoruf(int ragham) {
		// daryaft adade joda shode va tabdile an be harf az tarigh i moshabehe
		// arrayeha
		int a[] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
				17, 18, 19, 20, 30, 40, 50, 60, 70, 80, 90, 100, 200, 300, 400,
				500, 600, 700, 800, 900, 1000, 1000000, 1000000000 };
		String b[] = { "", "Yek", "Do", "Seh", "Chahar", "Panj", "Shesh",
				"Haft", "Hasht", "Noh", "Dah", "Yazdah", "Davazdah", "Sizdah",
				"Chahardah", "Panzdah", "Shanzdah", "Hefdah", "Hejdah",
				"Noozdah", "Bist", "Si", "Chehel", "Panjah", "Shast", "Haftad",
				"Hashtad", "Navad", "Sad", "Divist", "Sisad", "Chaharsad",
				"Pansad", "Sheshsad", "Haftsad", "Hashtsad", "Nohsad", "Hezar",
				"Yek Million", "Yek Milliard" };
		int i;

		for (i = 0; i <= 39; i++)
			if (a[i] == ragham) {
				break;
			}
		return b[i];

	}

	// ***************************ok
	public static String beHoruf(String adad) {
		int yekan, dahgan, sadgan, adad1;
		// joda kardn yekan dahgan va sadgan az ham

		String yeki, dahi, sadi, cavab = null;
		adad1 = Integer.parseInt(adad);
		yekan = adad1 % 10;
		yeki = TabdilBeHoruf(yekan);
		// *****
		dahgan = (adad1 % 100) - yekan;
		if (dahgan == 10) {
			dahgan = dahgan + yekan;
			dahi = TabdilBeHoruf(dahgan);
			dahgan = dahgan - yekan;
		} else
			dahi = TabdilBeHoruf(dahgan);
		// *****
		sadgan = (adad1 % 1000) - (dahgan + yekan);
		sadi = TabdilBeHoruf(sadgan);
		// *****barresi halate mokhtalef o gozari
		if (yekan == 0 && dahgan == 0 && sadgan == 0) {
			cavab = "";
		} else if (yekan != 0 && dahgan == 0 && sadgan == 0) {
			cavab = sadi + dahi + yeki;
		} else if (yekan == 0 && dahgan != 0 && sadgan == 0) {
			if (dahgan == 10)
				cavab = sadi + dahi;
			else
				cavab = sadi + dahi + " o " + yeki;
		} else if (yekan == 0 && dahgan == 0 && sadgan != 0) {
			cavab = sadi + dahi + yeki;
		} else if (yekan == 0 && dahgan != 0 && sadgan != 0) {
			if (dahgan == 10)
				cavab = sadi + "o" + dahi;
			else
				cavab = sadi + " o " + dahi + yeki;
		} else if (yekan != 0 && dahgan == 0 && sadgan != 0) {

			cavab = sadi + " o " + yeki;
		} else if (yekan != 0 && dahgan != 0 && sadgan == 0) {
			if (dahgan == 10)
				cavab = sadi + dahi;
			else
				cavab = sadi + dahi + " o " + yeki;
		}

		else if (yekan != 0 && dahgan != 0 && sadgan != 0) {
			if (dahgan == 10)
				cavab = sadi + " o " + dahi;
			else
				cavab = sadi + " o " + dahi + " o " + yeki;
		}
		return cavab;
	}

	// ***************************ok
	public static String beHoruf1(String num) {
		String[] x = { "", "", "", "", "", "", "", "", "", "", "", "" };
		String[] y = num.split("");// joda krdn tamami argham az hm
		if (y.length > 12)// barresi andaze
			return "khata\n adade shoma toolani tar az hade momken ast";// hle
		else {
			String let0, let1, let2, let3, aslHarf;
			// hatman bayad 12 ragham vared beshe vagarna
			// error)))))))))))))))))))))))))))))
			x[0] = num.substring(0, 3);// joda krdn 3ta 3tai string dade shode
										// va gozashtn pasvand barayeshan
			let0 = beHoruf(x[0]);
			if (let0 != "")
				let0 = let0 + " Milliard";

			x[1] = num.substring(3, 6);
			let1 = beHoruf(x[1]);
			if (let1 != "")
				let1 = let1 + " Million";

			x[2] = num.substring(6, 9);
			let2 = beHoruf(x[2]);
			if (let2 != "" && let2 != "Yek")
				let2 = let2 + " Hezar";
			else if (let2 == "Yek")// baraye inke yek hezar nage
				let2 = " Hezar";

			x[3] = num.substring(9, 12);
			let3 = beHoruf(x[3]);
			// *******************************************************
			// shart baraye o gozari
			if (let3 == "" && let2 == "" && let1 == "" && let0 == "")
				let3 = "Sefr";
			if (let3 != "" && let2 != "" && let1 != "" && let0 != "")
				aslHarf = let0 + " o " + let1 + " o " + let2 + " o " + let3;
			else {
				if (let3 != "" && let2 != "")
					let3 = " o " + let3;
				if (let1 != "" && let0 != "")
					let1 = " o " + let1;
				if (let2 != "" && let1 != "")
					let2 = " o " + let2;
				if (let0 != "" && let1 != "")
					let0 = let0 + " o ";
				if (let1 != "" && let2 != "")
					let1 = let1 + " o ";
				if (let2 != "" && let3 != "")
					let2 = let2 + " o ";
				if (let1 != "" && let3 != "")
					let1 = let1 + " o ";
				if (let0 != "" && let2 != "")
					let0 = let0 + " o ";
				if (let0 != "" && let3 != "")
					let0 = let0 + " o ";
				aslHarf = let0 + let1 + let2 + let3;
			}
			return aslHarf;
		}

	}

	// ***********************tabe asli
	public static void main(String[] args) {
		System.out
				.print("tabdil be adad ya horuf?\nagar horuf be adad (1)   va agar adad be horuf (0):  ");
		Scanner src = new Scanner(System.in);
		String a = src.nextLine();// daryafte 0 ya yek
		int b;
		b = Integer.parseInt(a);
		// *****************************************************************************************
		if (b == 0) {
			System.out
					.print("lotfan adade morede nazare khod ra be adad vared namayid:   \n");
			String num = src.nextLine();// daryafte adad
			System.out.println(beHoruf1(num));

		}
		// ******************************************************************************************
		else if (b == 1) { // esme tabe
			System.out
					.print("lotfan adade morede nazare khod ra be horuf vared namayid:   \n");
			String lett = src.nextLine();// daryafte adad
			System.out.println(BeAdad(lett));
		}
		src.close();
	}
}
