package sahar.uniguilan;

import java.util.ArrayList;


public class group extends functions {// guruh haye pish frz
	public ArrayList<String> favorites = new ArrayList<String>();
	public ArrayList<String> family = new ArrayList<String>();
	public ArrayList<String> unsigned = new ArrayList<String>();
	public ArrayList<String> friends = new ArrayList<String>();

	public void addEveryThing() {// aval az hme chiz mokhatabaro add mikone tu
									// unsined
		for (int i = 0; i < arraye.size(); i++) {
			unsigned.add(arraye.get(i));
		}
	}

	public void addGp(ArrayList<String> esmgp, String mokhatab) {
		int k = -1;
		for (int i = 0; i < arraye.size(); i++) {
			if (arraye.get(i).indexOf(mokhatab) != -1) {// peyda krdn mokhtb
				k = i;
				break;
			}
		}
		if (k == -1)
			System.out.println("not found!");
		else {
			if (esmgp.equals(family) == true) {
				unsigned.remove(k);// hazf az unsigned va ezafe be guruh
				family.add(arraye.get(k));
			} else if (esmgp.equals(favorites) == true) {
				unsigned.remove(k);
				favorites.add(arraye.get(k));
			} else if (esmgp.equals(friends) == true) {
				unsigned.remove(k);
				friends.add(arraye.get(k));
			}
		}
	}

	public void showgp(ArrayList<String> esmgp) {

		if (esmgp.equals(family) == true) {
			for (int i = 0; i < family.size(); i++)
				System.out.println(family.get(i));
		} else if (esmgp.equals(favorites) == true) {
			for (int i = 0; i < favorites.size(); i++)
				System.out.println(favorites.get(i));
		} else if (esmgp.equals(friends) == true) {
			for (int i = 0; i < friends.size(); i++)
				System.out.println(friends.get(i));
		}

	}

	public void deleteGp(ArrayList<String> esmgp, String mokhatab) {
		int k = -1;
		if (esmgp.equals(family) == true) {
			for (int i = 0; i < family.size(); i++) {
				if (family.get(i).indexOf(mokhatab) != -1) {
					unsigned.add(family.get(i));// ezafe be unsigned va hazf az
												// gp
					family.remove(i);
					k = i;
					break;
				}
			}
			if (k == -1)
				System.out.println("not found!");

		}// **********************************
		else if (esmgp.equals(favorites) == true) {
			for (int i = 0; i < favorites.size(); i++) {
				if (mokhatab.indexOf(favorites.get(i)) != -1) {
					unsigned.add(favorites.get(i));
					favorites.remove(i);
					k = i;
					break;
				}
			}
			if (k == 0)
				System.out.println("not found!");

		} else if (esmgp.equals(friends) == true) {
			for (int i = 0; i < friends.size(); i++) {
				if (friends.get(i).indexOf(mokhatab) != -1) {
					unsigned.add(friends.get(i));
					friends.remove(i);
					k = i;
					break;
				}
			}
			if (k == 0)
				System.out.println("not found!");

		}
	}

	public ArrayList<String> newgp() {
		ArrayList<String> gp = new ArrayList<String>();
		int k = 2;
		while (k == 2) {
			System.out.println("1.add 2.delete");
			int j = src.nextInt();
			System.out.println("which contact?");
			String esm = src.next();
			int i, o = 0;
			for (i = 0; i < arraye.size(); i++) {
				if (unsigned.get(i).indexOf(esm) != -1) {
					o++;
					break;
				}
			}
			if (o == 0)
				System.out.println("not found!");
			else {
				if (j == 1) {
					gp.add(arraye.get(i));
					unsigned.remove(i);
				} else {
					unsigned.add(arraye.get(i));
					gp.remove(arraye.get(i));
				}
			}
			System.out.println("finish?(1.yes/2.no)");
			o = src.nextInt();
		}
		return null;
	}

	public void deleteGp(ArrayList<String> esmgp) {
		if (esmgp.equals(family) == true) {
			int a = family.size();
			for (int i = 0; i < a; i++) {
				unsigned.add(family.get(0));
				family.remove(0);
			}
		} else if (esmgp.equals(favorites) == true) {
			int a = favorites.size();
			for (int i = 0; i < a; i++) {
				unsigned.add(favorites.get(0));
				favorites.remove(0);
			}
		} else if (esmgp.equals(friends) == true) {
			int a = friends.size();
			for (int i = 0; i < a; i++) {
				unsigned.add(friends.get(0));
				friends.remove(0);
			}
		}
	}
}
