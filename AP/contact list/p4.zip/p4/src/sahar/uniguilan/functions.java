package sahar.uniguilan;

import java.util.ArrayList;
import java.util.Scanner;


public class functions extends contact {

	public ArrayList<String> arraye = new ArrayList<String>();
	public static int[] q = new int[2];
	Scanner src = new Scanner(System.in);

	public void add(String esm) {
		arraye.add(esm);
	}

	// ************************************************
	public void showsize() {
		System.out.println(arraye.size());
	}

	// *************************************************
	public void delete(String esm) {
		int k = 0;
		for (int i = 0; i < arraye.size(); i++) {// aval mokhatabo peyda mikone
													// bad deletesh mikone
			if (arraye.get(i).indexOf(esm) != -1) {
				arraye.remove(i);
				k++;
				System.out.println("deleted!");
				break;
			}
		}
		if (k == 0) {
			System.out.println("not found!");
		}
	}

	// *************************************************
	public void find(String esm) {
		int k = 0;
		for (int i = 0; i < arraye.size(); i++) {
			if (arraye.get(i).indexOf(esm) != -1) {
				System.out.println("found:   " + arraye.get(i));
				k++;
				break;
			}
		}
		if (k == 0)
			System.out.println("not found!");
	}

	// ***********************************************************
	public void show() {
		for (int j = 0; j < arraye.size(); j++)
			System.out.println((j + 1) + "." + arraye.get(j));
	}

	// /***********************************************************
	/*
	 * public void findNeighbor(String esm) { for (int i = 0; i < arraye.size();
	 * i++) { if (esm.indexOf(arraye.get(i)) != -1) { try {
	 * System.out.println(arraye.get(i - 1)); } catch (Exception e) {
	 * System.out.println("dont have neighbour on top!"); } try {
	 * System.out.println(arraye.get(i + 1)); } catch (Exception e) {
	 * System.out.println("dont have neighbour on bottom!"); }
	 * 
	 * break; } } }
	 */
	// ****************************************************

	public void edit(String esm, int ghesmateEditi) {
		int k = -1;
		for (int i = 0; i < arraye.size(); i++) {
			if (arraye.get(i).indexOf(esm) != -1) {
				k = i;
				break;
			}
		}
		if (k == -1)
			System.out.println("not found!");
		String[] array = esm.split(",");// ,ha ro split mikone bad un ghesmati k
										// gharare edit beshe ro migire va bade
										// edite michasbune bhm
		if (ghesmateEditi == 1) {
			System.out.println("write your edition:");
			array[0] = src.next();
			String temp = "";
			for (int i = 0; i < array.length; i++) {
				if (i == array.length - 1)
					temp = temp + array[i];
				else {
					temp = temp + array[i] + ",";
				}
			}
			arraye.set(k, temp);
			System.out.println(temp);

		} else if (ghesmateEditi == 2) {
			System.out.println("write your edition:");
			array[1] = src.next();
			String temp = "";
			for (int i = 0; i < array.length; i++) {
				if (i == array.length - 1)
					temp = temp + array[i];
				else
					temp = temp + array[i] + ",";
			}
			arraye.set(k, temp);
			System.out.println(arraye.get(k));
		} else if (ghesmateEditi >= 3 && array.length >= 3) {
			System.out.println("write your edition:");
			array[ghesmateEditi - 1] = src.next();
			String temp = "";
			for (int i = 0; i < array.length; i++) {
				if (i == array.length - 1)
					temp = temp + array[i];
				else
					temp = temp + array[i] + ",";
			}
			arraye.set(k, temp);
			System.out.println(arraye.get(k));
		} else
			System.out.println("wrong number!");
	}

}
