package sahar.uniguilan;

import java.util.Scanner;


public class mix {
	public static void main(String[] args) {
		location a = new location();
		Scanner src = new Scanner(System.in);
		int adad = 0;
		while (adad != 4) {
			System.out
					.println("please enter the number of the function that you want");
			System.out.println(" 1.Adress Book   2.group   3.location 4.exite");
			adad = src.nextInt();
			if (adad == 1) {
				System.out
						.println("1.add   2.delete   3.find neighbour   4.showlist   5.count contacts   6.edit");
				int gozine = src.nextInt();
				String mokhatab;
				if (gozine == 1) {
					mokhatab = null;
					for (int i = 0; i < 100; i++) {
						System.out.println("please name the contact:");
						mokhatab = src.next();
						System.out
								.println("please enter the number of the contact:");
						mokhatab = mokhatab + "," + src.next();
						System.out
								.println("do you want to add details?(yes:1/no:2)");
						int j = src.nextInt();
						if (j == 1) {
							j = 2;// ********************************************************
							while (j == 2) {// BD,location,gender,group,email
								System.out
										.println("1.BirthDay,2.location,3.gender,4.group,5.email");
								System.out.println("enter Birth day:");
								mokhatab = mokhatab + "," + src.next();// ba
																		// ,neshaneha
																		// be hm
																		// vasl
																		// mishn
								System.out.println("finish?(1.yes,2.no)");
								j = src.nextInt();
								if (j == 1) {
									a.add(mokhatab);
									break;
								}

								System.out.println("enter location:");
								mokhatab = mokhatab + "," + src.next();
								System.out.println("finish?(1.yes,2.no)");
								j = src.nextInt();
								if (j == 1) {
									a.add(mokhatab);
									break;
								}
								System.out.println("enter gender:");
								mokhatab = mokhatab + "," + src.next();
								System.out.println("finish?(1.yes,2.no)");
								j = src.nextInt();
								if (j == 1) {
									a.add(mokhatab);
									break;
								}
								System.out.println("enter group:");
								mokhatab = mokhatab + "," + src.next();
								System.out.println("finish?(1.yes,2.no)");
								j = src.nextInt();
								if (j == 1) {
									a.add(mokhatab);
									break;
								}
								System.out.println("enter email:");
								mokhatab = mokhatab + "," + src.next();
								System.out.println("finish?(1.yes,2.no)");
								j = src.nextInt();
								if (j == 1) {
									a.add(mokhatab);
									break;
								}
							}
						} else
							a.add(mokhatab);
						System.out
								.println("do you want to add new contact?(1.yes   2.no)");
						int o = src.nextInt();
						if (o == 2)
							break;
					}
				}
				// **********************************************
				else if (gozine == 2) {
					int o = 1;
					while (o == 1) {
						System.out
								.print("write the name of the contact that you want to delete it:  ");
						a.delete(src.next());
						System.out
								.println("do you want to delete an other contact?(1.yes/2.no)");
						o = src.nextInt();
						if (o == 2)
							break;
					}
				} else if (gozine == 3) {
					int o = 1;
					while (o == 1) {
						System.out.println("which contact and radius?");
						a.findNeighbor(src.next(), src.nextInt());
						System.out
								.println("do you want to see an other contacts neighbor?(1.yes/2.no)");
						o = src.nextInt();
						if (o == 2)
							break;
					}
				} else if (gozine == 4) {
					a.show();
				} else if (gozine == 5) {
					a.showsize();
				} else if (gozine == 6) {
					System.out
							.println("please enter the name of the contact and the part that you want to edit\n"
									+ "1.name 2.number 3.BirthDay 4.location 5.gender 6.group 7.email");
					a.edit(src.next(), src.nextInt());

				}
			} else if (adad == 2) {
				System.out
						.println("which gp?1.family 2.favorite 3.friends 4.creat new gp");
				int k = src.nextInt();
				group New = new group();
				a.addEveryThing();
				if (k == 1) {
					// family
					System.out
							.println("1.add or 2.delete or 3.show or 4.deleteGp");
					int j = src.nextInt();
					if (j == 1) {
						while (j == 1) {
							System.out.println("which contact?");
							a.addGp(a.family, src.next());
							System.out.println("add more?(1.yes/2.no)");
							j = src.nextInt();
						}
					} else if (j == 2) {
						while (j == 1) {
							System.out.println("which contact?");
							a.deleteGp(a.family, src.next());
							System.out.println("delete more?(1.yes/2.no)");
							j = src.nextInt();
						}
					} else if (j == 3) {
						a.showgp(a.family);
					} else if (j == 4) {
						a.deleteGp(a.family);
					}
				} else if (k == 2) {
					// favorite
					System.out
							.println("1.add or 2.delete or 3.showor 4.deleteGp");
					int j = src.nextInt();
					if (j == 1) {
						while (j == 1) {
							System.out.println("which contact?");
							a.addGp(a.favorites, src.next());
							System.out.println("add more?(1.yes/2.no)");
							j = src.nextInt();
						}
					} else if (j == 2) {
						while (j == 1) {
							System.out.println("which contact?");
							a.deleteGp(a.favorites, src.next());
							System.out.println("delete more?(1.yes/2.no)");
							j = src.nextInt();
						}
					} else if (j == 3) {
						a.showgp(a.favorites);
					} else if (j == 4) {
						a.deleteGp(a.favorites);
					}
				} else if (k == 3) {
					// friends
					System.out
							.println("1.add or 2.delete or 3.showor 4.deleteGp");
					int j = src.nextInt();
					if (j == 1) {
						while (j == 1) {
							System.out.println("which contact?");
							a.addGp(a.friends, src.next());
							System.out.println("add more?(1.yes/2.no)");
							j = src.nextInt();
						}
					} else if (j == 2) {
						while (j == 1) {
							System.out.println("which contact?");
							a.deleteGp(a.friends, src.next());
							System.out.println("delete more?(1.yes/2.no)");
							j = src.nextInt();
						}
					} else if (j == 3) {
						a.showgp(a.friends);
					} else if (j == 4) {
						a.deleteGp(a.friends);
					}
				} else if (k == 4) {
					// new
					New.newgp();
				}
			}
			if (adad == 3) {
				// location
				System.out.println("which contact?");
				String esm = src.next();
				a.locationM(esm);
			}
		}

		src.close();
	}
}