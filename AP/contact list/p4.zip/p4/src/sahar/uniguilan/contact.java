package sahar.uniguilan;

public class contact {
	private String x;

	// dashtn metod x baraye neshane haye mokhatb
	public void setw(String w) {
		this.setX(w);

	}

	public String getw(String w) {
		return w;
	}

	public String getX() {
		return x;
	}

	public void setX(String x) {
		this.x = x;
	}

}
