package sahar.uniguilan;


public class location extends group {
	public String keshvar, shahr, ostan, kuche, mahale;
	public int[] x = new int[100];
	public int[] y = new int[100];
	public int[] r = new int[100];

	public int peyda(String esm) {
		int i, o = 0;
		for (i = 0; i < arraye.size(); i++) {
			if (arraye.get(i).indexOf(esm) != -1) {
				o++;
				break;
			}
		}
		if (o == 0)
			return -1;
		else
			return i;

	}

	public void locationM(String esm) {
		int a = peyda(esm);
		if (a == -1)
			System.out.println("not found!");
		else {
			// arraye.get
			System.out.println("please enter x:");
			x[a] = src.nextInt();
			System.out.println("please enter y:");
			y[a] = src.nextInt();

		}
	}

	public void findNeighbor(String esm, int r) {
		int a = peyda(esm);
		if (a == -1)
			System.out.println("not found!");
		else {
			for (int i = 0; i < arraye.size(); i++)
				if (i != a) {
					if (((x[a] - x[i]) * (x[a] - x[i]))
							+ ((y[a] - y[i]) * (y[a] - y[i])) < r * r) {
						System.out.println(arraye.get(i));
					}
				}
		}
	}

	public String getKeshvar() {
		return keshvar;
	}

	public void setKeshvar(String keshvar) {
		this.keshvar = keshvar;
	}

	public String getShahr() {
		return shahr;
	}

	public void setShahr(String shahr) {
		this.shahr = shahr;
	}

	public String getOstan() {
		return ostan;
	}

	public void setOstan(String ostan) {
		this.ostan = ostan;
	}

	public String getKuche() {
		return kuche;
	}

	public void setKuche(String kuche) {
		this.kuche = kuche;
	}

	public String getMahale() {
		return mahale;
	}

	public void setMahale(String mahale) {
		this.mahale = mahale;
	}

}
