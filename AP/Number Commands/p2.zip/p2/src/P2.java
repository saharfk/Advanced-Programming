import java.util.Scanner;

public class P2 {
	public static void main(String[] args) {
		System.out
				.println("lotfan amaliyat haye morede nazare khod ra ba _ joda krde va vared namayid");
		Scanner src = new Scanner(System.in);
		String lett = src.nextLine();// grftn dastur
		String[] lett2;
		if (lett.indexOf("_") != -1) {
			lett2 = new String[lett.split("_").length];
			lett2 = lett.split("_");// joda krdn bar asas _
		} else {
			lett2 = new String[1];
			lett2[0] = lett;
		}

		for (int az = 0; az < lett2.length; az++) {

			// ************************************************************************
			if (lett2[az].indexOf("add") != -1) {
				String[] b = lett2[az].split("\\(");
				String c = b[1].substring(0, b[1].length() - 1);
				String[] d = c.split(",");
				// ****grftn adadha az bein()
				String[] b1 = d[0].split("");// joda krdn argham adad
				String[] b2 = d[1].split("");
				int[] adad, adad2;
				if ((b1[0].equals("-") == true && b2[0].equals("-") == true)
						|| (b1[0].equals("-") == false && b2[0].equals("-") == false)) {
					// agar hr 2 - budn ya har do mosbt budn jam kon
					if (b1[0].equals("-") == true || b2[0].equals("-") == true) {
						b1[0] = "0";
						b2[0] = "0";// bardashtn manfi va ham andaze krdn adad
									// kuchktr be andaze adad bozorg
					}
					if (d[0].length() > d[1].length()) {// ham andaze kardan va
														// gozshtn 0 beja jahaye
														// khali

						adad = new int[d[0].length()];
						adad2 = new int[d[0].length()];
						for (int i = d[0].length() - 1; i >= 0; i--) {
							if (b1[0] == "0" && i == 0) {
								adad[0] = 0;
								break;
							}
							adad[i] = Integer.parseInt(b1[i]);

						}
						int j = d[1].length() - 1;
						for (int i = d[0].length() - 1; i >= 0; i--) {
							adad2[i] = Integer.parseInt(b2[j]);
							j--;
							if (j < 0)
								break;
						}
					} else {
						adad = new int[d[1].length()];
						adad2 = new int[d[1].length()];
						for (int i = d[1].length() - 1; i >= 0; i--)
							adad2[i] = Integer.parseInt(b2[i]);
						int j = d[0].length() - 1;
						for (int i = d[1].length() - 1; i >= 0; i--) {
							adad[i] = Integer.parseInt(b1[j]);
							j--;
							if (j < 0)
								break;
						}
					}
					int ezafe = 0;
					String[] javab = new String[adad.length];
					String[] jameStringi = new String[adad.length];
					// ***************hamandazegi
					for (int i = adad.length - 1; i >= 0; i--) {
						if (i != adad.length - 1) {
							if (jameStringi[i + 1].length() == 2)
								jameStringi[i] = String.valueOf(adad[i]
										+ adad2[i] + 1);// agar ragham ghabli
														// jamesh 2raghaami bud
														// javab jame 2 raghame
														// feli ra+1 kon
							else
								jameStringi[i] = String.valueOf(adad[i]
										+ adad2[i]);// dar gheire in surt adi
													// jam kon

							if (i == 0 && jameStringi[0].length() == 2) {
								ezafe = 1;
								// agar raghame aval az chap jamesh 2 raghmi
								// shod ezafe ro yek kon va ghabl namayesh javab
								// k faghat yekan haye jamha has ezafe ro
								// namayesh mide
							}
						} else {
							jameStringi[i] = String.valueOf(adad[i] + adad2[i]);
							// dr gheir in surt jam kon va b string tabdil kon

						}

						if (jameStringi[i].length() == 2)
							javab[i] = jameStringi[i].substring(1, 2);// agar
																		// javab
																		// jam
																		// 2raghami
																		// bud
																		// yekano
																		// briz
																		// tu
																		// java
						else
							javab[i] = jameStringi[i];// agar na khod adado briz
														// tu javab
					}
					if (b1[0].equals("0") == true && b2[0].equals("0") == true) {
						System.out.print("-");// manfi gozari agar adad avalie
												// raghame avalesh 0 shode bud
												// yani - bude pas -ra neshan bd
						if (ezafe == 1)
							System.out.print(ezafe);
						for (int i = 1; i < adad.length; i++)
							System.out.print(javab[i]);// neshan dadn javab
					} else {// dar ghaire in surt javabo bdun - namayesh mide
						if (ezafe == 1)
							System.out.print(ezafe);
						for (int i = 0; i < adad.length; i++)
							System.out.print(javab[i]);
						System.out.println();
					}
				}// **********************************************************tafrigh

				else if ((b1[0].equals("-") == true && b2[0].equals("-") == false)
						|| (b1[0].equals("-") == false && b2[0].equals("-") == true)) {
					int[] adad3, adad4;// agar yki - bud o yki + kam kon
					adad = new int[b1.length];
					adad2 = new int[b2.length];
					if (b1[0].equals("-") == true) {
						adad[0] = 0;// tabdil manfi b 0 ba tabdil 2adad b int
						for (int i = 1; i < b1.length; i++)
							adad[i] = Integer.parseInt(b1[i]);
						for (int i = 0; i < b2.length; i++)
							adad2[i] = Integer.parseInt(b2[i]);
					}

					if (b2[0].equals("-") == true) {
						adad2[0] = 0;
						for (int i = 1; i < b2.length; i++)
							adad2[i] = Integer.parseInt(b2[i]);
						for (int i = 0; i < b1.length; i++)
							adad[i] = Integer.parseInt(b1[i]);
					}
					if (adad.length > adad2.length) {
						adad3 = new int[adad.length];
						adad4 = new int[adad.length];// hm andaze
						int j = adad2.length - 1;
						for (int i = adad.length - 1; i >= 0; i--) {
							adad4[i] = adad2[j];
							j--;// az adad2.len ta adad2[0] mirize tu adad4 k
								// ham andaze adad bozorgas va baghiye khuneha 0
								// mimune
							if (j < 0)
								break;
						}
						for (int i = 0; i < adad.length; i++)
							adad3[i] = adad[i];
					}// hm andaze
					else {
						adad3 = new int[adad2.length];// hm andaze
						adad4 = new int[adad2.length];
						int j = adad.length - 1;
						for (int i = adad2.length - 1; i >= 0; i--) {
							adad3[i] = adad[j];
							j--;
							if (j < 0)
								break;
						}
						for (int i = 0; i < adad3.length; i++)
							adad4[i] = adad2[i];
					}// hm andaze

					// ****************************************************
					for (int i = 0; i < adad3.length; i++) {
						if (adad3[i] > adad4[i]) {// bade ham andaze sazi
													// moghaye mikone bbine
													// kodum adad bozorg tare k
													// uno az digri km kone
							for (int i1 = 0; i1 < adad3.length; i1++)// manfi
																		// gozari
							{// agr adad bozorge - bud -bitun mide
								if (adad3[i1] > adad4[i1]
										&& b1[0].equals("-") == true) {
									System.out.print("-");
									break;
								} else if (adad3[i1] > adad4[i1]
										&& b2[0].equals("-") == true)
									System.out.print("");
								else
									System.out.print("");
							}// manfi gozari

							// kam krdn
							int[] d1 = new int[adad4.length];
							for (int i1 = adad4.length - 1; i1 >= 0; i1--) {
								if (adad3[i1] < adad4[i1] && i1 != 0) {
									// agar raghame adad bozorge az adad kuchike
									// kuchiktr bud bhsh 10ta ezafe kon va az
									// raghame ghablish yeki km kon
									d1[i1] = (adad3[i1] + 10) - adad4[i1];
									adad3[i1 - 1] = adad3[i1 - 1] - 1;
								} else {// agar na faghat km kon
									d1[i1] = adad3[i1] - adad4[i1];

								}
							}

							if (d1[0] == 0)
								for (int i1 = 1; i1 < adad4.length; i1++) {
									System.out.print(d1[i1]);// birun ddn javab
								}
							else
								for (int i1 = 0; i1 < adad4.length; i1++)
									System.out.print(d1[i1]);
							break;
						}// **************************
						else if (adad3[i] < adad4[i]
								|| (i == adad3.length - 1 && adad3[i] == adad4[i])) {
							for (int i1 = 0; i1 < adad3.length; i1++) {// axe
																		// halate
																		// ghabl
								if (adad3[i1] < adad4[i1]
										&& b1[0].equals("-") == true)
									System.out.print("");
								else if (adad3[i1] < adad4[i1]
										&& b2[0].equals("-") == true) {
									System.out.print("-");
									break;
								} else
									System.out.print("");
							}

							int[] d1 = new int[adad3.length];
							for (int i1 = adad3.length - 1; i1 >= 0; i1--) {
								if (adad4[i1] < adad3[i1] && i1 != 0) {
									d1[i1] = (adad4[i1] + 10) - adad3[i1];
									adad4[i1 - 1] = adad4[i1 - 1] - 1;
								} else {
									d1[i1] = adad4[i1] - adad3[i1];

								}
							}

							if (d1[0] == 0)
								for (int i1 = 1; i1 < adad3.length; i1++) {
									System.out.print(d1[i1]);
								}
							else
								for (int i1 = 0; i1 < adad3.length; i1++)
									System.out.print(d1[i1]);

							break;
						}
					}
				}

				// ************************************************************************
			} else if (lett2[az].indexOf("sub") != -1// eine jame faghat shorute
														// avalie jabe ja shodn
														// yani vaghti adad+-
														// bashn jam va agr ++
														// ya --bashan km mishn
					&& lett2[az].indexOf("subNumber") == -1) {
				String[] b = lett2[az].split("\\(");
				String c = b[1].substring(0, b[1].length() - 1);
				String[] d = c.split(",");
				// ******
				String[] b1 = d[0].split("");// joda krdn adad
				String[] b2 = d[1].split("");
				int[] adad, adad2;
				if ((b1[0].equals("-") == true && b2[0].equals("-") == false)
						|| (b1[0].equals("-") == false && b2[0].equals("-") == true)) {

					if (b1[0].equals("-") == true) {
						System.out.print("-");
						b1[0] = "0";
					}
					if (b2[0].equals("-") == true) {
						b2[0] = "0";
					}
					if (d[0].length() > d[1].length()) {// ham andaze kardan
														// va sefr gozari
						// ghabl
						// adad
						adad = new int[d[0].length()];
						adad2 = new int[d[0].length()];
						for (int i = d[0].length() - 1; i >= 0; i--) {
							if (b1[0] == "0" && i == 0) {
								adad[0] = 0;
								break;
							}
							adad[i] = Integer.parseInt(b1[i]);

						}
						int j = d[1].length() - 1;
						for (int i = d[0].length() - 1; i >= 0; i--) {
							adad2[i] = Integer.parseInt(b2[j]);
							j--;
							if (j < 0)
								break;
						}
					} else {
						adad = new int[d[1].length()];
						adad2 = new int[d[1].length()];
						for (int i = d[1].length() - 1; i >= 0; i--)
							adad2[i] = Integer.parseInt(b2[i]);
						int j = d[0].length() - 1;
						for (int i = d[1].length() - 1; i >= 0; i--) {
							adad[i] = Integer.parseInt(b1[j]);
							j--;
							if (j < 0)
								break;
						}
					}
					int ezafe = 0;
					String[] javab = new String[adad.length];
					String[] jameStringi = new String[adad.length];
					// ***************hamandazegi
					for (int i = adad.length - 1; i >= 0; i--) {
						if (i != adad.length - 1) {
							if (jameStringi[i + 1].length() == 2)
								jameStringi[i] = String.valueOf(adad[i]
										+ adad2[i] + 1);
							else
								jameStringi[i] = String.valueOf(adad[i]
										+ adad2[i]);

							if (i == 0 && jameStringi[0].length() == 2) {
								ezafe = 1;

							}
						} else {
							jameStringi[i] = String.valueOf(adad[i] + adad2[i]);

						}

						if (jameStringi[i].length() == 2)
							javab[i] = jameStringi[i].substring(1, 2);
						else
							javab[i] = jameStringi[i];
					}
					if (b1[0].equals("0") == true && b2[0].equals("0") == true) {

						if (ezafe == 1)
							System.out.print(ezafe);
						for (int i = 1; i < adad.length; i++)
							System.out.print(javab[i]);
					} else {
						if (ezafe == 1)
							System.out.print(ezafe);
						for (int i = 0; i < adad.length; i++)
							System.out.print(javab[i]);

					}
				}// **********************************************************tafrigh

				else if ((b1[0].equals("-") == true && b2[0].equals("-") == true)
						|| (b1[0].equals("-") == false && b2[0].equals("-") == false)) {
					int[] adad3, adad4;
					adad = new int[b1.length];
					adad2 = new int[b2.length];
					if (b1[0].equals("-") == true) {
						b1[0] = "0";
						b2[0] = "0";
					}
					for (int i = 0; i < b1.length; i++)
						adad[i] = Integer.parseInt(b1[i]);
					for (int i = 0; i < b2.length; i++)
						adad2[i] = Integer.parseInt(b2[i]);

					if (adad.length > adad2.length) {
						adad3 = new int[adad.length];
						adad4 = new int[adad.length];// hm andaze
						int j = adad2.length - 1;
						for (int i = adad.length - 1; i >= 0; i--) {
							adad4[i] = adad2[j];
							j--;
							if (j < 0)
								break;
						}
						for (int i = 0; i < adad.length; i++)
							adad3[i] = adad[i];
					}// hm andaze
					else {
						adad3 = new int[adad2.length];// hm andaze
						adad4 = new int[adad2.length];
						int j = adad.length - 1;
						for (int i = adad2.length - 1; i >= 0; i--) {
							adad3[i] = adad[j];
							j--;
							if (j < 0)
								break;
						}
						for (int i = 0; i < adad3.length; i++)
							adad4[i] = adad2[i];
					}// hm andaze

					// ****************************************************
					for (int i = 0; i < adad3.length; i++) {
						if (adad3[i] > adad4[i]) {
							for (int i1 = 0; i1 < adad3.length; i1++)// manfi
																		// gozari
							{

								if (adad3[i1] > adad4[i1]
										&& d[0].substring(0, 1).equals("-") == true) {
									System.out.print("-");
									break;
								} else if (adad3[i1] > adad4[i1]
										&& d[0].substring(0, 1).equals("-") == false)
									System.out.print("");

							}// manfi gozari

							// kam krdn
							int[] d1 = new int[adad4.length];
							for (int i1 = adad4.length - 1; i1 >= 0; i1--) {
								if (adad3[i1] < adad4[i1] && i1 != 0) {
									d1[i1] = (adad3[i1] + 10) - adad4[i1];
									adad3[i1 - 1] = adad3[i1 - 1] - 1;
								} else {
									d1[i1] = adad3[i1] - adad4[i1];

								}
							}

							if (d1[0] == 0)
								for (int i1 = 1; i1 < adad4.length; i1++) {
									System.out.print(d1[i1]);
								}
							else
								for (int i1 = 0; i1 < adad4.length; i1++)
									System.out.print(d1[i1]);
							break;
						}// **************************
						else if (adad3[i] < adad4[i]
								|| (i == adad3.length - 1 && adad3[i] == adad4[i])) {
							for (int i1 = 0; i1 < adad3.length; i1++) {
								if (adad3[i1] < adad4[i1]
										&& d[0].substring(0, 1).equals("-") == true)
									System.out.print("");
								else if (adad3[i1] < adad4[i1]
										&& d[0].substring(0, 1).equals("-") == false) {
									System.out.print("-");
									break;
								} else
									System.out.print("");
							}// tafrigh***********************************

							int[] d1 = new int[adad3.length];
							for (int i1 = adad3.length - 1; i1 >= 0; i1--) {
								if (adad4[i1] < adad3[i1] && i1 != 0) {
									d1[i1] = (adad4[i1] + 10) - adad3[i1];
									adad4[i1 - 1] = adad4[i1 - 1] - 1;
								} else {
									d1[i1] = adad4[i1] - adad3[i1];

								}
							}

							if (d1[0] == 0)
								for (int i1 = 1; i1 < adad3.length; i1++) {
									System.out.print(d1[i1]);
								}
							else
								for (int i1 = 0; i1 < adad3.length; i1++)
									System.out.print(d1[i1]);

							break;
						}
					}
				}
				System.out.println();

				// ************************************************************************
			} else if (lett2[az].indexOf("pow") != -1) {//

				System.out.println("error");
				// ************************************************************************
			} else if (lett2[az].indexOf("fact") != -1) {

				System.out.println("error");
				// ************************************************************************
			} else if (lett2[az].indexOf("nextPerm") != -1) {
				String[] b = lett2[az].split("\\(");
				String c = b[1].substring(0, b[1].length() - 1);
				String[] a = c.split("");// joda krdn adad
				int[] c1 = new int[c.length()];
				int b1 = 0;
				for (int i = 0; i < c.length(); i++)
					c1[i] = Integer.parseInt(a[i]);// tbdil b int
				for (int i = c.length() - 1; i > -1; i--) {
					if (i == 0) {
						System.out.print("-1");// agar ta akhar rft va badi
												// az ghabli
												// kuchaktr nbud -1
						break;
					} else {
						if (c1[i] > c1[i - 1] && i != 0) {// dar gheire in
															// surt ja b jai
							b1 = c1[i - 1];
							c1[i - 1] = c1[i];
							c1[i] = b1;
							for (int j = 0; j < c.length(); j++)
								System.out.print(c1[j]);// neshan ddn adad
							break;
						}

					}
				}

				System.out.print("\n");

				// ************************************************************************
			} else if (lett2[az].indexOf("mod") != -1) {

				System.out.println("error");

				// ************************************************************************
			} else if (lett2[az].indexOf("rep") != -1) {
				String[] b = lett2[az].split("\\(");
				String c = b[1].substring(0, b[1].length() - 1);
				String[] d = c.split(",");
				long a = Integer.parseInt(d[1]);// tabdil b adad
				for (int i = 0; i < a; i++)
					System.out.print(d[0]);// tekrar krdn adad b tedade
											// gofte shode
				System.out.print("\n");

				// ************************************************************************
			} else if (lett2[az].indexOf("isPalindromes") != -1) {

				String[] b = lett2[az].split("\\(");
				if (b[1].equals(",)"))
					System.out.println("True");
				else {
					String c = b[1].substring(0, b[1].length() - 1);
					String[] d = c.split(",");
					if (d[0].length() != d[1].length())
						System.out.println("False");// agar andazehayeshan
													// barabar nabud
													// ghalat
					else {
						String[] a = d[0].split("");// joda krdn adad
						int[] c1 = new int[d[0].length()];

						for (int i = 0; i < d[0].length(); i++)
							c1[i] = Integer.parseInt(a[i]);// tbdil b int

						String[] a2 = d[1].split("");// joda krdn adad2
						int[] c2 = new int[d[1].length()];

						for (int i = 0; i < d[1].length(); i++)
							c2[i] = Integer.parseInt(a2[i]);// tbdil b int adad2

						int j = d[1].length() - 1;
						for (int i = 0; i < d[0].length(); i++) {
							if (c1[i] == c2[j]) {// moghayese araye aval adad
													// aval ba araye
													// akhare adade dovom
								if (i == 0) {
									System.out.println("True");
									// agar b akharin araye az adad aval resid
									// yani hme barabar budn pas dorost
									break;
								}
							} else {
								System.out.println("False");
								// agar na ghalat
								break;
							}
							j--;
						}
					}
				}
				// ************************************************************************
			} else if (lett2[az].indexOf("sumOfDigits") != -1) {
				String[] b = lett2[az].split("\\(");
				String c = b[1].substring(0, b[1].length() - 1);
				String[] a = c.split("");// joda krdn argham
				long javab = 0;
				int[] b1 = new int[a.length];
				for (int i = 0; i < a.length; i++)
					b1[i] = Integer.parseInt(a[i]);// tabdil b int
				for (int i = 0; i < b1.length; i++)
					javab += b1[i];// jam krdn argham
				System.out.println(javab);// neshan ddn javab

				// ************************************************************************
			} else if (lett2[az].indexOf("sort") != -1) {

				String[] b = lett2[az].split("\\(");
				String c = b[1].substring(0, b[1].length() - 1);
				String[] a = c.split("");// joda sazi adad
				int[] b1 = new int[a.length];// bara tabdil b int
				int min, iMin;
				for (int j = 0; j < a.length; j++) {
					b1[j] = Integer.parseInt(a[j]);// tabdil b int
				}
				for (int i = 0; i < b1.length - 1; i++)// mortb sazi
														// entekhabi
				{
					min = b1[i];// baze sazi baraye mortb sazi
					iMin = i;
					for (int j = i + 1; j < b1.length; j++)
						if (min > b1[j]) {
							min = b1[j];// peyda krdn kuchk trin adad va avardn
										// b aval araye va sepas kuchkte krdn
										// baze
							iMin = j;
						}
					b1[iMin] = b1[i];
					b1[i] = min;
				}
				for (int i = 0; i < b1.length; i++) {
					if (b1[i] != 0)
						System.out.print(b1[i]);// neshan ddn adad
				}
				System.out.print("\n");

				// ************************************************************************
			} else if (lett2[az].indexOf("rotate") != -1) {
				// bara adadi k az length adad asli kuchktrn va tu int ja mishn
				// javab mide
				/*
				 * agar kode taghsimo mizdm adade rotato unghad taghsim krdm ta
				 * tu int ya long ja beshe bad hm andaze un adadhaye be dast
				 * umde rotate mikrdm
				 */
				String[] b = lett2[az].split("\\(");
				String c = b[1].substring(0, b[1].length() - 1);
				String[] d = c.split(",");
				int a = Integer.parseInt(d[1]);// tabdil tedad gam ha b adad
				String[] b1 = d[0].split("");// joda krdn adad bozorg
				String[] c1 = new String[d[0].length()];// rikhtn adad dr
														// arayei jadid
				for (int i = 0; i < d[0].length(); i++)
					c1[i] = b1[i];
				if (a < b1.length) {
					if (a < 0)// baresi gam baraye rast ya chap rftn
					{
						a = a * -1;
						for (int i = 0; i < d[0].length(); i++) {
							c1[((i + (d[0].length() - a)) % d[0].length())] = b1[i];
						}
						for (int i = 0; i < d[0].length(); i++)
							System.out.print(c1[i]);// neshan ddn adad
						System.out.println();
					} else {
						for (int i = d[0].length() - 1; i >= a; i--)
							b1[i] = c1[(i - a)];
						int j = 0;
						for (int i = (a - 1); i >= 0; i--) {
							b1[i] = c1[(d[0].length() - 1) - j];
							j++;
						}
						for (int i = 0; i < d[0].length(); i++)
							System.out.print(b1[i]);// neshan ddn adad
						System.out.println();

					}
				} else
					System.out.println("error");
				// ************************************************************************
			} else if (lett2[az].indexOf("subNumber") != -1) {
				String[] b = lett2[az].split("\\(");
				String c = b[1].substring(0, b[1].length() - 1);
				String[] d = c.split(",");
				int a = Integer.parseInt(d[1]);// grftn shoru baze
				int b1 = Integer.parseInt(d[2]);// grftn payan baze

				if (a < 0 || b1 <= 0 || a >= d[0].length() - 1
						|| b1 >= d[0].length())
					System.out.println("null");// shorute null budn
				else
					System.out.print(d[0].substring(a, b1));// neshan
															// ddn
															// javb
				System.out.println();
				// ************************************************************************
			} else if (lett2[az].indexOf("indexOf") != -1) {
				String[] b = lett2[az].split("\\(");
				String c = b[1].substring(0, b[1].length() - 1);
				String[] d = c.split(",");
				String a = d[0].substring(0, 1);// joda krdn rghm aval adad
												// aval
				for (int i = 0; i < d[1].length(); i++) {
					if (a.equals(d[1].substring(i, i + 1)) == true) {
						System.out.print(i + "  ");// neshn ddn shomare
													// indexha
					}
				}

				for (int i = 0; i <= d[1].length(); i++) {// baresi dobare baze
															// bara zamani k
															// barabr nbudn
					if (i == d[1].length()) {
						System.out.print("-1");// agar b in adad resid yani
												// barabar
												// nabude pas -1
						break;
					}
					if (a.equals(d[1].substring(i, i + 1)) == true) {
						break;// agar barabar bud ke yani index darim
					}
				}
				System.out.print("\n");

				// ************************************************************************
			} else if (lett2[az].indexOf("split") != -1) {
				String[] b = lett2[az].split("\\(");
				String c = b[1].substring(0, b[1].length() - 1);
				String[] d = c.split(",");
				String[] a = d[1].split("");// joda sazi va rikhtn aadad dar
											// araye
				String[] b1 = d[0].split("");

				for (int i = 0; i < d[1].length(); i++) {
					// moghayese tak tak khanehaye adade dovom ba tamam khane
					// haye
					// adade aval
					for (int j = 0; j < d[0].length(); j++) {
						if (b1[j].equals(a[i]) == true) {
							b1[j] = "_";// agar barabr budn _ migozard

						}
					}
				}
				for (int i = 0; i < d[0].length(); i++)
					System.out.print(b1[i]);// neshan dadn adad ba _
				System.out.print("\n");

				// ************************************************************************
			}
		}

		src.close();
	}

}
